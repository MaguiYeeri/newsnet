<?php 
		require_once '../controller/index.php';
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Actualités MGLSI</title>
	<link rel="stylesheet" type="text/css" href="view/style/style.css">
</head>
<body>
	<?php require_once '../view/entete.php'; ?>
	<div id="contenu">
		<?php
			
				foreach ($articles as $article)
				{?>
					<div class="article">
						<h1><a href="../view/article.php?id=<?= $article->id ?>"><?= $article->titre ?></a></h1>
						<p><?= substr($article->contenu, 0, 300) . '...' ?></p>
					</div>
	</div>
	<?php 
		}
		require_once '../view/menu.php'; 
	?>
</body>
</html>