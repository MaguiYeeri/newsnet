<div id="entete">
	<h1>Site d'actualité du MGLSI</h1>
	<!-- <hr> -->
</div>