<?php 
		require_once '../controller/article.php';
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Affichage d'un article</title>
	<link rel="stylesheet" type="text/css" href="../view/style/style.css">
</head>
<body>
	<div id="contenu">
	<?php 
		require_once '../view/entete.php';
		
		if (isset($_GET['id']))
		{
			?>
				<h1><?= $article->titre ?></h1>
				<span>Publié le <?= $article->dateCreation ?></span>
				<p><?= $article->contenu ?></p>
			</div><?php
		}
		else if  (isset($_GET['categorie']))
		{

			if (empty($articles)) {
				echo "Aucun article dans cette catégorie";
			}
			else
			{
				foreach ($articles as $article)
				{?>
					<div class="article">
						<h1><a href="../view/article.php?id=<?= $article->id ?>"><?= $article->titre ?></a></h1>
						<p><?= substr($article->contenu, 0, 300) . '...' ?></p>
					</div><?php
				}
			}
		}
		else
		{?>
			<meta http-equiv="refresh" content="3; url=../index.php">
			<p>Cet article n'existe pas !!!</p><?php
		}
	?>
	</div>
	<?php 
		require_once '../view/menu.php'; 
	?>
</body>
</html>