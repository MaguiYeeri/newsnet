
	<?php 
		require_once '../model/fonctions.php';
		$bdd = dbConnect();
		if (isset($_GET['id']))
		{
			
				$id = (int) $_GET['id'];
		$article = getItem($bdd, $id);
		header('../view/article.php?id='.$id);
		}
		else if  (isset($_GET['categorie']))
		{
			$catId = (int) $_GET['categorie'];
			$articles = getItemByCategorie($bdd, $catId);
			if (empty($articles)) {
				echo "Aucun article dans cette catégorie";
			}
		header('../view/article.php?categorie='.$catId);	
		}
		$categories = getList($bdd, 'Categorie');
		 
	?>
