
	<?php 
		require_once '../model/fonctions.php';
		$bdd = dbConnect();
		if ($bdd != null)
			{
		$articles = getList($bdd);

		$categories = getList($bdd, 'Categorie');
			}
			else
			{
				echo "Aucun article trouvé";
			}
			header('../view/article.php');
	?>
