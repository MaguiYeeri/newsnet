﻿<?php 

     include '../controlleur/indexControl.php';

    //Ne pas oublier d'ajouter le fichier Article.php
   
 ?>
<!DOCTYPE html>
<html lang="fr">
    <head>
        <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Favicon-->
        <link rel="shortcut icon" href="img/fav.png">
        <!-- Author Meta -->
        <meta name="author" content="E-news">
        <!-- Meta Description -->
        <meta name="description" content="Site de news">
        <!-- Meta Keyword -->
        <meta name="keywords" content="actualité, news, information">
        <!-- meta character set -->
        <meta charset="UTF-8">
        <!-- Site Title -->
        <title>E-News</title>
        <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet">
        <!--
        CSS
        ============================================= -->
        <link rel="stylesheet" href="styles/linearicons.css">
        <link rel="stylesheet" href="styles/font-awesome.min.css">
        <link rel="stylesheet" href="styles/bootstrap.css">
        <link rel="stylesheet" href="styles/magnific-popup.css">
        <link rel="stylesheet" href="styles/nice-select.css">
        <link rel="stylesheet" href="styles/animate.min.css">
        <link rel="stylesheet" href="styles/owl.carousel.css">
        <link rel="stylesheet" href="styles/jquery-ui.css">
        <link rel="stylesheet" href="styles/sweetalert.css">
        <link rel="stylesheet" href="styles/main.css">
    </head>
    <body>
        <header>
            
            <div class="header-top">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-6 header-top-left no-padding">
                            <ul>
                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="logo-wrap">
                <div class="container">
                    
                </div>
            </div>
            <div class="container main-menu" id="main-menu">
                <div class="row align-items-center justify-content-between">
                    <nav id="nav-menu-container">
                        <ul class="nav-menu">
                            <li class="menu-active"><a href="index.php">Accueil</a></li>
                            <li class="menu-has-children"><a href="">Catégorie</a>
                            <ul>
                                <?php
                                    while($categorie = $allcat->fetch())
                                    {
                                ?>
                                    <li><a href="article_par_categorie.php?idCategorie=<?php echo ($categorie->idCat);?>"><?= htmlspecialchars($categorie->nom);?></a></li>
                                <?php
                                    }
                                    $allcat->closeCursor();
                                ?>
                            </ul>
                        </li>
                        <li><a href="contact.php">Nous Contacter</a></li>
                    </ul>
                    </nav><!-- #nav-menu-container -->
                    
                </div>
            </div>
        </header>
<div class="site-main-container">
    <!-- Start top-post Area -->

    <section class="top-post-area pt-10">
        <div class="container no-padding">
            <div class="row small-gutters">
                <?php
                    while($article = $principal->fetch())
                    {
                ?>
                    <div class="col-lg-8 top-post-left">
                        <div class="feature-image-thumb relative">
                            <div class="overlay overlay-bg"></div>
                            <img class="img-fluid" src="medias/<?= htmlspecialchars($article->image);?>" alt="">
                        </div>
                        <div class="top-post-details">
                            <ul class="tags">
                                <li><?= htmlspecialchars($article->nom);?></li>
                            </ul>
                            <a href="../vue/detail_article.php?idArticle=<?php echo ($article->idArticle);?>">
                                <h3><?= htmlspecialchars($article->titre);?>.</h3>
                            </a>
                            <ul class="meta">
                                <li><span class="lnr lnr-calendar-full"></span><?= htmlspecialchars($article->datePub);?></li>
                            </ul><br>
                        </div>
                    </div>
            <?php
                }
                $principal->closeCursor();
            ?>
                <div class="col-lg-4 top-post-right">
                    <?php
                        while($article = $last->fetch())
                        {
                    ?>
                            <div class="single-top-post">
                                <div class="feature-image-thumb relative">
                                    <div class="overlay overlay-bg"></div>
                                    <img class="img-fluid" src="medias/<?= htmlspecialchars($article->image);?>" alt="">
                                </div>
                                <div class="top-post-details">
                                    <ul class="tags">
                                        <li><?= htmlspecialchars($article->nom);?></li>
                                    </ul>
                                    <a href="../vue/detail_article.php?idArticle=<?php echo ($article->idArticle);?>">
                                        <h4><?= htmlspecialchars($article->titre);?></h4>
                                    </a>
                                    <ul class="meta">
                                        <li><span class="lnr lnr-calendar-full"></span><?= htmlspecialchars($article->datePub);?></li>
                                    </ul>
                                </div>
                            </div><br>
                    <?php
                        }
                        $last->closeCursor();
                    ?>
                    
                </div>
                
            </div>
        </div>
    </section>

	<section class="latest-post-area pb-120">
        <div class="container no-padding">
            <div class="row">
                <div class="col-lg-12 post-list">
                    <!-- Start latest-post Area -->
                    <div class="latest-post-wrap">
                        <h4 class="cat-title">Latest News</h4>
                            <?php
                                while($article = $all->fetch())
                                {
                            ?>
                                    <div class="single-latest-post row align-items-center">
                                        <div class="col-lg-5 post-left">
                                            <div class="feature-img relative">
                                                <div class="overlay overlay-bg"></div>
                                                <img class="img-fluid" src="medias/<?= htmlspecialchars($article->image);?>" alt="">
                                            </div>
                                            <ul class="tags">
                                                <li><?= htmlspecialchars($article->nom);?></li>
                                            </ul>
                                        </div>
                                        <div class="col-lg-7 post-right">
                                            <a href="../vue/detail_article.php?idArticle=<?php echo ($article->idArticle);?>">
                                                <h4><?= htmlspecialchars($article->titre);?></h4>
                                            </a>
                                            <ul class="meta">
                                                <li><span class="lnr lnr-calendar-full"></span><?= htmlspecialchars($article->datePub);?></li>
                                            </ul>
                                            <p class="excert">
                                            <?= htmlspecialchars($article->description);?>
                                            </p>
                                        </div>
                                    </div>
                                <?php
                                    }
                                    $all->closeCursor();
                                ?>
                        
                    </div>
                </div>
            </div>
        </div>
    </section>

</div>



<?php include 'footer.php'; ?>