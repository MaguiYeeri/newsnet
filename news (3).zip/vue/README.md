# mglsi_news
Projet Architecture logiciel
