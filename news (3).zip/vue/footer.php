
		<!-- start footer Area -->
		<footer class="footer-area section-gap">
			<div class="container">
				
				<div class="footer-bottom row align-items-center">
					<p class="footer-text m-0 col-lg-8 col-md-12"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        Copyright &copy;<script>document.write(new Date().getFullYear());</script> 
                    </p>
					<div class="col-lg-4 col-md-12 footer-social">
						<a href="#"><i class="fa fa-facebook"></i></a>
						<a href="#"><i class="fa fa-twitter"></i></a>
						<a href="#"><i class="fa fa-dribbble"></i></a>
						<a href="#"><i class="fa fa-behance"></i></a>
					</div>
				</div>
			</div>
		</footer>
		<!-- End footer Area -->
		<script src="scripts/vendor/jquery-2.2.4.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.scripts/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
		<script src="scripts/vendor/bootstrap.min.js"></script>
		<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
		<script src="scripts/easing.min.js"></script>
		<script src="scripts/hoverIntent.js"></script>
		<script src="scripts/superfish.min.js"></script>
		<script src="scripts/jquery.ajaxchimp.min.js"></script>
		<script src="scripts/jquery.magnific-popup.min.js"></script>
		<script src="scripts/mn-accordion.js"></script>
		<script src="scripts/jquery-ui.js"></script>
		<script src="scripts/jquery.nice-select.min.js"></script>
		<script src="scripts/owl.carousel.min.js"></script>
		<script src="scripts/mail-script.js"></script>
		<script src="scripts/sweetalert.js"></script>
		<script src="scripts/main.js"></script>
	</body>
</html>