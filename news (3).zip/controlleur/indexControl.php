 <?php 
  require_once '../modele/Database.php';
 require_once '../modele/Article.php';
 require_once '../modele/Categorie.php';
  $Categories = new Categorie();
    $allcat = $Categories->getCategorie();
    $article = new Article();
    $principal = $article->getPrincipalArticle();

    $last = $article->getLastArticles();

    $all = $article->getArticles();
    
  
 header('./vue/index.php');
    ?>