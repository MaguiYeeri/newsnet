 <?php 
 require_once '../modele/Database.php';
 require_once '../modele/Article.php';
 require '../modele/Categorie.php';
  
  $Categories = new Categorie();
    $allcat = $Categories->getCategorie();
    $article = new Article();
    $idArticle = "";
    if (isset($_GET['idArticle'])) 
    {
        $idArticle = $_GET['idArticle'];
    }
    header("Location: ../vue/detail_article.php?idArticle=".$idArticle);
    $detail = $article->getDetailArticle($idArticle);

    $value = $detail->fetch()
 
    ?>