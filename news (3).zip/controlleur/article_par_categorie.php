  <?php 
    require_once '../modele/Database.php';
  	 require '../modele/Article.php';
      require '../modele/Categorie.php';
  	$article = new Article();
    $Categories = new Categorie();
    $allcat = $Categories->getCategorie();
    $idCategorie = "";
    if (isset($_GET['idCategorie'])) 
    {
        $idCategorie = $_GET['idCategorie'];
    }
     header('./vue/article_par_categorie.php?$idCategorie='.$idCategorie);
    $all = $article->getArticleParCategorie($idCategorie);

    $categorie = $article->getNomCategorie($idCategorie);
    $value = $categorie->fetch()

     
   ?>