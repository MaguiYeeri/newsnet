<?php 
	require_once '../modele/Database.php';
	require_once '../modele/Categorie.php';
    require_once '../modele/Article.php';
    $Categories = new Categorie();
    $allcat = $Categories->getCategorie();
    include '../vue/header.php';
?>